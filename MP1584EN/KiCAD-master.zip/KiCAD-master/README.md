# KiCAD
KiCAD Symbol and Footprint

1. MP1584: unlike other libraries, our symbol 100% same as MP1584 Datasheet. We put BST (pin 8) at top and GND (pin 5) at bottom side
2. Wemos D1 Mini: this version removes Courtyards from built KiCAD footprint, so you can put footprint under Wemos (supposed you want to use Pin Socket for Wemos then put a resistor below Wemos)
3. Next component will be put here :)
